-- Minimal schema used for the portfolio exercises.
-- Import the corresponding Berka dataset files into these tables.
-- The original .asc files are semicolon-delimited, with a header.
CREATE TABLE account (
    account_id INTEGER PRIMARY KEY,
    district_id INTEGER,
    frequency VARCHAR(50),
    date INTEGER
);
CREATE TABLE client (
    client_id INTEGER PRIMARY KEY,
    birth_number BIGINT,
    district_id INTEGER
);
CREATE TABLE disp (
    disp_id INTEGER PRIMARY KEY,
    client_id INTEGER REFERENCES client(client_id),
    account_id INTEGER REFERENCES account(account_id),
    type VARCHAR(20)
);
CREATE TABLE trans (
    trans_id INTEGER PRIMARY KEY,
    account_id INTEGER REFERENCES account(account_id),
    date INTEGER,
    type VARCHAR(30),
    operation VARCHAR(100),
    amount NUMERIC(15,2),
    balance NUMERIC(15,2),
    k_symbol VARCHAR(50),
    bank VARCHAR(10),
    account INTEGER
);
