-- Flag transactions exceeding five times their account average.
-- This is an exploratory anomaly indicator, not proof of fraud.
-- Filter using the unrounded ratio to avoid boundary errors.
WITH account_averages AS (
    SELECT
        t.account_id,
        t.trans_id,
        t.amount AS transaction_amount,
        AVG(t.amount) OVER (PARTITION BY t.account_id) AS avg_account_amount
    FROM trans AS t
),
transaction_ratios AS (
    SELECT
        account_id,
        trans_id,
        transaction_amount,
        ROUND(avg_account_amount, 2) AS avg_account_amount,
        transaction_amount / NULLIF(avg_account_amount, 0) AS raw_ratio
    FROM account_averages
)
SELECT
    account_id, trans_id, transaction_amount, avg_account_amount,
    ROUND(raw_ratio, 2) AS ratio
FROM transaction_ratios
WHERE raw_ratio > 5
ORDER BY raw_ratio DESC
LIMIT 15;

-- Monthly transaction amount and month-over-month change (original query)

--Evolution mensuelle des transactions

with evolution as (
select
to_char (to_date(lpad(date::TEXT, 6, '0'), 'YYMMDD'), 'YYYY-MM') as date_v2,
sum(amount) as mtt_transactions,
lag(sum(amount)) over (
order by to_char (to_date(lpad(date::TEXT, 6, '0'), 'YYMMDD'), 'YYYY-MM')
) as mtt_precedent
from trans
group by date_v2),

variation as (select 
date_v2, 
mtt_transactions, 
mtt_precedent, 
round(((mtt_transactions/nullif(mtt_precedent,0))-1)*100.0, 2) as variation_trans
from evolution)

select *
from variation
order by date_v2;
