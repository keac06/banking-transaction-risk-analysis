-- PostgreSQL declarative range partitioning by transaction date.
-- Run once in a database containing the original trans table.
-- Dataset dates were verified to span 1993-01-01 through 1998-12-31.
-- No primary key is declared because a partitioned unique/primary key
-- must include the partition key (date_transaction).

CREATE TABLE trans_partitionnees (
    trans_id INTEGER,
    account_id INTEGER,
    date_transaction DATE NOT NULL,
    amount NUMERIC(15,2),
    type VARCHAR(30)
) PARTITION BY RANGE (date_transaction);

CREATE TABLE trans_1993_1994 PARTITION OF trans_partitionnees
    FOR VALUES FROM ('1993-01-01') TO ('1995-01-01');
CREATE TABLE trans_1995_1996 PARTITION OF trans_partitionnees
    FOR VALUES FROM ('1995-01-01') TO ('1997-01-01');
CREATE TABLE trans_1997_1998 PARTITION OF trans_partitionnees
    FOR VALUES FROM ('1997-01-01') TO ('1999-01-01');

INSERT INTO trans_partitionnees
    (trans_id, account_id, date_transaction, amount, type)
SELECT trans_id, account_id,
       TO_DATE(LPAD(date::TEXT, 6, '0'), 'YYMMDD'), amount, type
FROM trans;

-- Verify counts across physical partitions.
SELECT tableoid::regclass AS partition, COUNT(*) AS transaction_count
FROM trans_partitionnees
GROUP BY tableoid
ORDER BY partition;

-- Partition pruning: only trans_1995_1996 should be scanned.
EXPLAIN (ANALYZE, BUFFERS)
SELECT * FROM trans_partitionnees
WHERE date_transaction >= '1995-01-01'
  AND date_transaction < '1996-01-01';
