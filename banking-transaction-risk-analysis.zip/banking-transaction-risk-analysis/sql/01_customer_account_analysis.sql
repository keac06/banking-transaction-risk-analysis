-- Customer and account analysis (original queries)
-- Requires account, client and disp tables from the Berka dataset.

--liste des clients avec les comptes bancaires auxquels ils sont associés

select c.client_id, d.account_id, d.type, a.frequency
from client c
inner join disp d
on c.client_id=d.client_id
inner join account a
on d.account_id=a.account_id
order by c.client_id
limit 10;

--Identification des clients possédant plusieurs comptes

select c.client_id, count(distinct(d.account_id)) as nombre_comptes
from client c
inner join disp d
on c.client_id=d.client_id
group by c.client_id
having count(distinct(d.account_id)) > 1
order by nombre_comptes DESC, c.client_id;

--Identification des comptes partagés


select a.account_id, count(distinct(d.client_id)) as nombre_clients
from account a
inner join disp d
on a.account_id=d.account_id
group by a.account_id
having count(distinct(d.client_id)) > 1
order by nombre_clients DESC, a.account_id;

--Nombre de comptes partagés
with nombre as (select a.account_id, count(distinct(d.client_id)) as nombre_clients
from account a
inner join disp d
on a.account_id=d.account_id
group by a.account_id
having count(distinct(d.client_id)) > 1
order by nombre_clients DESC, a.account_id)

select count(*)
from nombre;

--Répartition des relations entre les clients et leurs comptes : Owner et Disponent

select 
disp.type, 
count(*) as nombre_relations,
concat(round(((count(*) * 100.0)
/sum(count(*)) over()),2),' %') as pourcentage_repartition
from disp 
group by disp.type
order by count(*) DESC;

--Analyse des comptes bancaires par district

select district_id, 
count(*) as nombre_comptes,
concat(round(((count(*) * 100.0)
/sum(count(*)) over()),2),' %') as pourcentage_repartition
from account
group by district_id
order by count(*) DESC
limit 10;

--Identification des districts les plus importants

WITH comptes_par_district AS (
select 
district_id, 
count(account_id) as nombre_comptes,
rank() over(
order by count(account_id) DESC) as rank
from account
group by district_id
)

SELECT *
FROM comptes_par_district
where rank <= 5
ORDER BY rank, district_id;


--identificztion des districts qui possèdent plus de comptes que la moyenne des districts

With nombre_c as (
select 
district_id,
count(account_id) as nombre_comptes,
round(AVG(count(account_id)) OVER (),2) as moyenne
from account
group by district_id), 

classement as (select 
district_id, nombre_comptes, moyenne, 
round(nombre_comptes-moyenne,2) as ecart 
from nombre_c)

select *
from classement 
where ecart > 0
order by ecart DESC;


--Analyse des comptes par fréquence de relevés

with pourcent as (
select 
frequency,
count(account_id) as nombre_comptes,
round((count(account_id)*100.0)/sum(count(account_id)) over (),2) as pourcentage
from account
group by frequency)

select frequency, nombre_comptes, pourcentage, 
dense_rank() over (order by nombre_comptes DESC) as rang
from pourcent;

--nombre de comptes par client, en distinguant les titulaires des personnes autorisées

with nbr_clients as(
select 
c.client_id as client_id, 
count(distinct(d.account_id)) as nombre_comptes,
sum(case when d.type = 'OWNER' then 1 else 0 end) as nbr_comptes_titulaires,
sum(case when d.type = 'DISPONENT' then 1 else 0 end) as nbr_comptes_autorises
from client c
inner join disp d
on c.client_id = d.client_id
group by c.client_id),

classement as (
select 
client_id, 
nombre_comptes, 
nbr_comptes_titulaires, 
nbr_comptes_autorises,
dense_rank() over( order by nombre_comptes DESC) as rang
from nbr_clients
)

select * 
from classement
order by client_id
limit 10;
