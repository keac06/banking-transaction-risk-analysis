-- Transaction volume analysis
-- Requires account and trans tables.

--les 10 comptes bancaires avec le plus de transactions

select 
a.account_id, 
count(*) as nbr_transactions,
sum(amount) as montant_total
from account a
inner join trans t
on a.account_id = t.account_id
group by a.account_id
order by nbr_transactions DESC
limit 10;
