-- Query optimization experiment: account_id = 100
-- Baseline observed execution time: 185.351 ms (Parallel Seq Scan).
-- Indexed observed execution time: 1.924 ms (Bitmap Index Scan + Bitmap Heap Scan).
-- Results are from individual runs and are not a controlled benchmark.

-- Baseline: run BEFORE creating the index.
EXPLAIN (ANALYZE, BUFFERS)
SELECT * FROM trans WHERE account_id = 100;

-- Create index; rerunning this script safely skips creation.
CREATE INDEX IF NOT EXISTS idx_trans_account_id ON trans(account_id);
ANALYZE trans;

-- Indexed query plan.
EXPLAIN (ANALYZE, BUFFERS)
SELECT * FROM trans WHERE account_id = 100;
