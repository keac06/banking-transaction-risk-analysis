# Banking Transaction & Risk Analysis

**PostgreSQL · SQL · Banking analytics · Query optimization · Table partitioning**

## Overview

Portfolio SQL project exploring customer-account relationships, banking transaction patterns, and basic transaction anomaly indicators using the public **Berka / PKDD'99 Czech Financial Dataset**. The analysis covers **1,056,320 transactions** dated **1993–1998**.

The project demonstrates practical analytical SQL and database performance techniques; it is **not** a production fraud-detection system.

## Key analyses

- Customer-to-account relationships, shared accounts, and owner vs. authorized-user roles.
- Account distribution by district and statement frequency.
- High-activity accounts and transaction volumes.
- Exploratory detection of transactions greater than **5×** their account's average transaction amount.
- Monthly transaction totals and month-over-month percentage changes using `LAG()`.
- Query plan inspection with `EXPLAIN (ANALYZE, BUFFERS)` and indexing.
- Declarative date-range partitioning and verification of partition pruning.

## Results

- **Index experiment:** query time decreased from **185.351 ms** to **1.924 ms** in two measured executions (approximately **96.3× faster**). This is an illustrative result, not a controlled benchmark.
- **Partitioning:** transactions distributed into three two-year partitions: 119,833 (1993–94), 329,801 (1995–96), and 606,686 (1997–98).
- **Partition pruning:** a query restricted to 1995 scanned only the 1995–96 partition, returning 133,022 transactions.

See [`results/performance_comparison.md`](results/performance_comparison.md) for measured details.

## Repository structure

```text
sql/
  00_schema.sql
  01_customer_account_analysis.sql
  02_transaction_analysis.sql
  03_risk_and_monthly_trends.sql
  04_query_optimization.sql
  05_table_partitioning.sql
results/
  performance_comparison.md
README.md
```

## Dataset and setup

1. Download the public **Berka / PKDD'99 Czech Financial Dataset** from a legitimate dataset source. The repository does not redistribute the original data.
2. Create a PostgreSQL database, for example `banking_analysis`.
3. Run `sql/00_schema.sql` **once** to create the four tables used here.
4. Import `account.asc`, `client.asc`, `disp.asc`, and `trans.asc` in that order. In pgAdmin's import dialog, select CSV format, **semicolon (`;`) delimiter**, header enabled, and UTF-8 encoding.
5. Run the analysis scripts `01` through `03`.
6. For performance testing, run the **baseline** section of `04` before creating the index; then run its index and post-index sections.
7. Run `05` **once** to create and populate the partitioned table. Re-running without dropping the created tables will cause errors.

**Date note:** the original `trans.date` field is an integer encoded as `YYMMDD`; analysis queries convert it using `TO_DATE(LPAD(date::TEXT, 6, '0'), 'YYMMDD')`.

## SQL concepts

`JOIN` · `GROUP BY` · `HAVING` · CTEs · `CASE` · `RANK()` · `DENSE_RANK()` · `AVG() OVER` · `LAG()` · `NULLIF()` · `EXPLAIN ANALYZE` · `CREATE INDEX` · `PARTITION BY RANGE`

## Limitations

- The anomaly threshold is a simple statistical heuristic and should not be interpreted as a fraud label.
- `SUM(amount)` represents total recorded transaction amounts, not necessarily net cash flow.
- Execution timings are environment-dependent and are not based on repeated benchmarking.
- The example partitioned table includes a subset of columns from `trans` for teaching purposes.

## Project status

Completed SQL portfolio exercise. Queries were developed and tested in PostgreSQL/pgAdmin.
