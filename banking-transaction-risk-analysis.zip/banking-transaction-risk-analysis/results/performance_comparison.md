# Performance and partitioning results

## Index experiment (`account_id = 100`)

| Metric | Before index | After index |
|---|---:|---:|
| Execution time | 185.351 ms | 1.924 ms |
| Plan | Parallel Seq Scan | Bitmap Index Scan + Bitmap Heap Scan |
| Returned rows | 405 | 405 |

Observed speedup: **96.3×** (~98.96% less execution time). These are two individual runs, not a controlled benchmark; timings vary with caching and system load.

## Partitioning experiment

| Partition | Transaction count |
|---|---:|
| `trans_1993_1994` | 119,833 |
| `trans_1995_1996` | 329,801 |
| `trans_1997_1998` | 606,686 |
| **Total** | **1,056,320** |

For a 1995 date filter, PostgreSQL scanned only `trans_1995_1996` (partition pruning), returning **133,022 rows** in **100.242 ms**. This confirms pruning, not a proven speedup relative to an unpartitioned baseline.
